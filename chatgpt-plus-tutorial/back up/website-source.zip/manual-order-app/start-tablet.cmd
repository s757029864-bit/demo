@echo off
cd /d "%~dp0"
node local-start.mjs --lan
pause
