import {randomBytes,scryptSync,timingSafeEqual} from 'node:crypto';
import {backup} from 'node:sqlite';
import {mkdirSync,readdirSync,statSync,readFileSync,existsSync} from 'node:fs';
import path from 'node:path';

export function createManagement({db,products,dataDir,fail,json,admin,session,password,view}){
 const now=()=>Date.now();
 db.exec(`CREATE TABLE IF NOT EXISTS catalog(id TEXT PRIMARY KEY,name TEXT NOT NULL,cents INTEGER NOT NULL,category TEXT NOT NULL,active INTEGER NOT NULL DEFAULT 1,description TEXT NOT NULL DEFAULT '');
 CREATE TABLE IF NOT EXISTS inventory(id INTEGER PRIMARY KEY,product TEXT NOT NULL,code TEXT NOT NULL UNIQUE,status TEXT NOT NULL DEFAULT 'available',order_id TEXT,created INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS tickets(id INTEGER PRIMARY KEY,order_id TEXT NOT NULL,reason TEXT NOT NULL,status TEXT NOT NULL DEFAULT 'open',reply TEXT NOT NULL DEFAULT '',created INTEGER NOT NULL,updated INTEGER NOT NULL);
 CREATE TABLE IF NOT EXISTS settings(key TEXT PRIMARY KEY,value TEXT NOT NULL);
 CREATE INDEX IF NOT EXISTS order_created ON orders(created);CREATE INDEX IF NOT EXISTS ticket_order ON tickets(order_id);`);
 if(!db.prepare('PRAGMA table_info(catalog)').all().some(x=>x.name==='sale_stock'))db.exec('ALTER TABLE catalog ADD COLUMN sale_stock INTEGER');
 const columns=db.prepare('PRAGMA table_info(orders)').all().map(x=>x.name);
 for(const [key,type] of Object.entries({name_snapshot:"TEXT NOT NULL DEFAULT ''",note:"TEXT NOT NULL DEFAULT ''",paid_at:'INTEGER',fulfilled_at:'INTEGER',refund_cents:'INTEGER NOT NULL DEFAULT 0',refund_reference:'TEXT',refund_reason:'TEXT',refunded_at:'INTEGER'}))if(!columns.includes(key))db.exec(`ALTER TABLE orders ADD COLUMN ${key} ${type}`);
 for(const p of products)db.prepare('INSERT OR IGNORE INTO catalog(id,name,cents,category) VALUES(?,?,?,?)').run(p.id,p.name,p.cents,p.id.startsWith('google-')?'google':p.id==='sms-us'?'sms':'chatgpt');
 db.exec("UPDATE orders SET name_snapshot=COALESCE((SELECT name FROM catalog WHERE catalog.id=orders.product),product) WHERE name_snapshot='';UPDATE orders SET paid_at=updated,fulfilled_at=updated WHERE status='fulfilled' AND paid_at IS NULL;");
 db.exec("INSERT OR IGNORE INTO inventory(product,code,status,order_id,created) SELECT product,code,'sold',id,created FROM orders WHERE code IS NOT NULL AND status='fulfilled';");
 const getSetting=(key,fallback='')=>db.prepare('SELECT value FROM settings WHERE key=?').get(key)?.value??fallback;
 const setSetting=(key,value)=>db.prepare('INSERT INTO settings VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value').run(key,String(value));
 if(!getSetting('password')){const salt=randomBytes(16).toString('hex');setSetting('password',salt+':'+scryptSync(password,salt,64).toString('hex'));}
 const verifyPassword=entered=>{if(typeof entered!=='string'||entered.length>500)return false;const [salt,encoded]=getSetting('password').split(':');return timingSafeEqual(scryptSync(entered,salt,64),Buffer.from(encoded,'hex'));};
 const audit=(id,action)=>db.prepare('INSERT INTO audit(order_id,action,created) VALUES(?,?,?)').run(id,action,now());
 const transaction=fn=>{db.exec('BEGIN IMMEDIATE');try{const result=fn();db.exec('COMMIT');return result;}catch(e){db.exec('ROLLBACK');if(String(e).includes('UNIQUE'))fail('交易单号或交付内容已被其他订单使用',409);throw e;}};
 const listProducts=()=>db.prepare("SELECT c.*,(SELECT COUNT(*) FROM inventory i WHERE i.product=c.id AND i.status='available') AS inventoryStock FROM catalog c ORDER BY rowid").all().map(p=>({...p,stock:p.sale_stock??p.inventoryStock}));
 const getProduct=id=>db.prepare('SELECT * FROM catalog WHERE id=? AND active=1').get(id);
 const int=(value,min,max)=>Number.isInteger(value)&&value>=min&&value<=max;
 const clean=(value,max)=>String(value??'').trim().slice(0,max);
 const adminView=o=>({...view(o),name:o.name_snapshot,contact:o.contact,reference:o.reference,note:o.note,code:o.code,paidAt:o.paid_at,fulfilledAt:o.fulfilled_at,refundCents:o.refund_cents,refundReference:o.refund_reference,refundReason:o.refund_reason});
 function orderQuery(url,all=false){
  const where=[],args=[],q=clean(url.searchParams.get('q'),150),status=url.searchParams.get('status'),product=url.searchParams.get('product');
  if(q){where.push('(id LIKE ? ESCAPE \'\\\' OR contact LIKE ? ESCAPE \'\\\' OR reference LIKE ? ESCAPE \'\\\')');const term='%'+q.replace(/[\\%_]/g,'\\$&')+'%';args.push(term,term,term);}
  if(status&&status!=='all'){if(!['pending','review','paid','fulfilled','cancelled','refunded'].includes(status))fail('订单状态无效');where.push('status=?');args.push(status);}
  if(product&&product!=='all'){where.push('product=?');args.push(product);}
  for(const [key,op] of [['from','>='],['to','<']]){const value=url.searchParams.get(key);if(value){if(!/^\d{4}-\d{2}-\d{2}$/.test(value))fail('日期格式无效');const ts=Date.parse(value+'T00:00:00+08:00');if(!Number.isFinite(ts))fail('日期格式无效');where.push('created'+op+'?');args.push(ts+(key==='to'?86400000:0));}}
  const sql=where.length?' WHERE '+where.join(' AND '):'',page=Math.max(1,parseInt(url.searchParams.get('page')||'1')||1),size=20;
  const total=db.prepare('SELECT COUNT(*) n FROM orders'+sql).get(...args).n;
  if(all&&total>10000)fail('单次最多导出10000笔，请缩小日期范围');
  const orders=db.prepare('SELECT * FROM orders'+sql+' ORDER BY created DESC,id DESC'+(all?'':' LIMIT ? OFFSET ?')).all(...args,...(all?[]:[size,(page-1)*size])).map(adminView);
  return {orders,total,page,size};
 }
 function csv(value){let s=String(value??'');if(/^[\s]*[=+@\-]/.test(s))s="'"+s;return '"'+s.replaceAll('"','""')+'"';}
 function stats(){const counts=Object.fromEntries(db.prepare('SELECT status,COUNT(*) n FROM orders GROUP BY status').all().map(x=>[x.status,x.n]));const totals=db.prepare("SELECT COALESCE(SUM(CASE WHEN paid_at IS NOT NULL THEN cents ELSE 0 END),0) gross,COALESCE(SUM(refund_cents),0) refunds FROM orders").get();const day=new Date(now()+8*3600000).toISOString().slice(0,10),start=Date.parse(day+'T00:00:00+08:00');return {counts,...totals,net:totals.gross-totals.refunds,todayOrders:db.prepare('SELECT COUNT(*) n FROM orders WHERE created>=?').get(start).n,todayReceipts:db.prepare('SELECT COALESCE(SUM(cents),0) n FROM orders WHERE paid_at>=?').get(start).n,openTickets:db.prepare("SELECT COUNT(*) n FROM tickets WHERE status='open'").get().n,availableStock:db.prepare("SELECT COUNT(*) n FROM inventory WHERE status='available'").get().n,recent:db.prepare("SELECT strftime('%Y-%m-%d',created/1000,'unixepoch','+8 hours') day,COUNT(*) orders FROM orders GROUP BY day ORDER BY day DESC LIMIT 14").all()};}
 const backupsDir=path.join(dataDir,'backups');mkdirSync(backupsDir,{recursive:true});
 async function route(req,res,p,b,url){
  if(req.method==='GET'&&p==='/api/products'){json(res,200,{products:listProducts().filter(p=>p.active),paymentMode:'manual',channels:['wechat'],settings:{shopName:getSetting('shopName','商品与使用指南'),contact:getSetting('contact','sxzhaoniu'),announcement:getSetting('announcement','付款后由客服人工核实到账并发货。')}});return true;}
  const customerTicket=p.match(/^\/api\/orders\/([A-Z0-9]+)\/support$/);
  if(customerTicket){return false;}
  if(!p.startsWith('/api/admin/')||['/api/admin/login','/api/admin/logout'].includes(p))return false;
  const s=admin(req,req.method==='POST');
  if(req.method==='GET'&&p==='/api/admin/overview'){json(res,200,{stats:stats(),csrf:s.csrf});return true;}
  if(req.method==='GET'&&p==='/api/admin/orders'){json(res,200,{...orderQuery(url),csrf:s.csrf});return true;}
  if(req.method==='GET'&&p==='/api/admin/export'){
   const rows=orderQuery(url,true).orders;const fields=['id','name','cents','status','contact','reference','note','created','refundCents'];const text='\uFEFF'+[fields.map(csv).join(','),...rows.map(o=>fields.map(k=>csv(o[k])).join(','))].join('\r\n');audit('system','export.orders');res.setHeader('Content-Type','text/csv; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="orders.csv"');res.end(text);return true;
  }
  const detail=p.match(/^\/api\/admin\/orders\/([A-Z0-9]+)$/);
  if(req.method==='GET'&&detail){const o=db.prepare('SELECT * FROM orders WHERE id=?').get(detail[1]);if(!o)fail('订单不存在',404);json(res,200,{order:adminView(o),history:db.prepare('SELECT * FROM audit WHERE order_id=? ORDER BY id DESC').all(o.id),tickets:db.prepare('SELECT * FROM tickets WHERE order_id=? ORDER BY id DESC').all(o.id)});return true;}
  const action=p.match(/^\/api\/admin\/orders\/([A-Z0-9]+)\/(confirm|fulfill|cancel|note|refund|replace)$/);
  if(req.method==='POST'&&action){
   const id=action[1],kind=action[2],o=db.prepare('SELECT * FROM orders WHERE id=?').get(id);if(!o)fail('订单不存在',404);
   transaction(()=>{
    if(kind==='note'){const note=clean(b.note,2000);db.prepare('UPDATE orders SET note=?,updated=? WHERE id=?').run(note,now(),id);audit(id,'note.updated');return;}
    if(kind==='cancel'){if(!['pending','review'].includes(o.status))fail('只能取消尚未确认到账的订单',409);db.prepare("UPDATE orders SET status='cancelled',updated=? WHERE id=?").run(now(),id);audit(id,'order.cancelled');return;}
    if(kind==='refund'){
     if(!o.paid_at||!['paid','fulfilled'].includes(o.status))fail('该订单不能登记退款',409);if(b.confirmed!==true||b.amountCents!==o.cents)fail('请完成线下全额退款并核对金额');const reference=clean(b.reference,100),reason=clean(b.reason,1000);if(reference.length<6||reason.length<3)fail('请填写退款交易单号及原因');if(db.prepare('SELECT id FROM orders WHERE refund_reference=?').get(reference))fail('该退款交易单号已被登记',409);
     db.prepare("UPDATE orders SET status='refunded',refund_cents=cents,refund_reference=?,refund_reason=?,refunded_at=?,updated=? WHERE id=?").run(reference,reason,now(),now(),id);if(o.code)db.prepare("UPDATE inventory SET status='void' WHERE order_id=?").run(id);audit(id,'refund.recorded_after_manual_transfer');return;
    }
    if(kind==='replace'){
     if(o.status!=='fulfilled')fail('只能对已发货订单补发',409);const code=clean(b.code,4000),reason=clean(b.reason,1000);if(code.length<3||reason.length<3||b.confirmed!==true)fail('请填写新交付内容和原因并确认旧内容作废');const old=db.prepare('SELECT * FROM inventory WHERE code=?').get(code);if(old&&(old.status!=='available'||old.product!==o.product))fail('该交付内容不属于可用库存',409);if(code===o.code)fail('新旧交付内容不能相同');db.prepare("UPDATE inventory SET status='void' WHERE order_id=? AND status='sold'").run(id);if(old)db.prepare("UPDATE inventory SET status='sold',order_id=? WHERE id=?").run(id,old.id);else db.prepare("INSERT INTO inventory(product,code,status,order_id,created) VALUES(?,?,'sold',?,?)").run(o.product,code,id,now());db.prepare('UPDATE orders SET code=?,updated=? WHERE id=?').run(code,now(),id);audit(id,'delivery.replaced: '+reason);return;
    }
    if(kind==='fulfill'&&o.status==='fulfilled')return;
    if(!['pending','review','paid'].includes(o.status))fail('订单已关闭，不能确认或发货',409);
    if(o.status!=='paid'){
     const reference=clean(b.reference,100);if(b.confirmed!==true||b.amountCents!==o.cents||reference.length<6)fail('请核实实际到账金额、真实交易单号并勾选确认');db.prepare("UPDATE orders SET status='paid',reference=?,paid_at=?,updated=? WHERE id=?").run(reference,now(),now(),id);audit(id,'payment.confirmed');
    }
    if(kind==='confirm')return;
    const catalogProduct=db.prepare('SELECT sale_stock FROM catalog WHERE id=?').get(o.product);if(catalogProduct?.sale_stock!==null&&catalogProduct?.sale_stock!==undefined){if(catalogProduct.sale_stock<=0)fail('可售库存不足',409);db.prepare('UPDATE catalog SET sale_stock=sale_stock-1 WHERE id=?').run(o.product);}
    let code=clean(b.code,4000);let stock;
    if(b.source==='stock'){stock=db.prepare("SELECT * FROM inventory WHERE product=? AND status='available' ORDER BY id LIMIT 1").get(o.product);if(!stock)fail('该商品没有可用库存，请先导入或手动填写',409);code=stock.code;}
    else {if(code.length<3)fail('请填写交付内容');stock=db.prepare('SELECT * FROM inventory WHERE code=?').get(code);if(stock&&(stock.product!==o.product||stock.status!=='available'))fail('交付内容已使用或不属于本商品',409);}
    if(stock)db.prepare("UPDATE inventory SET status='sold',order_id=? WHERE id=? AND status='available'").run(id,stock.id);else db.prepare("INSERT INTO inventory(product,code,status,order_id,created) VALUES(?,?,'sold',?,?)").run(o.product,code,id,now());
    db.prepare("UPDATE orders SET status='fulfilled',code=?,fulfilled_at=?,updated=? WHERE id=?").run(code,now(),now(),id);audit(id,'delivery.fulfilled');
   });json(res,200,{ok:true,alreadyFulfilled:kind==='fulfill'&&o.status==='fulfilled'});return true;
  }
  if(p==='/api/admin/products'){
   if(req.method==='GET'){json(res,200,{products:listProducts()});return true;}
   if(req.method==='POST'){
    const id=clean(b.id,40),name=clean(b.name,100),description=clean(b.description,1000);if(!/^[a-z0-9-]{2,40}$/.test(id)||name.length<2||!int(b.cents,1,10000000)||!['chatgpt','google','sms','skills'].includes(b.category)||typeof b.active!=='boolean')fail('请检查商品编号、名称、价格或分类');
    if(b.saleStock!==undefined&&b.saleStock!==null&&!int(b.saleStock,0,10000000))fail('可售库存需要0至10000000的整数');
    transaction(()=>{db.prepare('INSERT INTO catalog(id,name,cents,category,active,description) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,cents=excluded.cents,category=excluded.category,active=excluded.active,description=excluded.description').run(id,name,b.cents,b.category,b.active?1:0,description);if(b.saleStock!==undefined)db.prepare('UPDATE catalog SET sale_stock=? WHERE id=?').run(b.saleStock,id);audit(id,'product.saved');});json(res,200,{ok:true});return true;
   }
  }
  if(req.method==='GET'&&p==='/api/admin/inventory'){
   const product=url.searchParams.get('product'),state=url.searchParams.get('status');const clauses=[],args=[];if(product&&product!=='all'){clauses.push('product=?');args.push(product);}if(state&&state!=='all'){if(!['available','sold','void'].includes(state))fail('库存状态无效');clauses.push('status=?');args.push(state);}const where=clauses.length?' WHERE '+clauses.join(' AND '):'',page=Math.max(1,parseInt(url.searchParams.get('page')||'1')||1);json(res,200,{items:db.prepare('SELECT id,product,status,order_id,created,substr(code,1,3) AS preview FROM inventory'+where+' ORDER BY id DESC LIMIT 20 OFFSET ?').all(...args,(page-1)*20),total:db.prepare('SELECT COUNT(*) n FROM inventory'+where).get(...args).n,page});return true;
  }
  if(req.method==='POST'&&p==='/api/admin/inventory/import'){
   if(!db.prepare('SELECT id FROM catalog WHERE id=?').get(b.product))fail('商品不存在');if(!Array.isArray(b.codes)||!b.codes.length||b.codes.length>200)fail('每次可导入1至200份');const codes=b.codes.map(x=>clean(x,4000));if(codes.some(x=>x.length<3))fail('每份交付内容至少3个字');let added=0,duplicates=0;transaction(()=>{for(const code of codes){if(db.prepare('SELECT id FROM inventory WHERE code=?').get(code)||db.prepare('SELECT id FROM orders WHERE code=?').get(code)){duplicates++;continue;}db.prepare('INSERT INTO inventory(product,code,created) VALUES(?,?,?)').run(b.product,code,now());added++;}audit(b.product,`inventory.imported ${added}; duplicates ${duplicates}`);});json(res,200,{added,duplicates});return true;
  }
  const stockAction=p.match(/^\/api\/admin\/inventory\/(\d+)\/(reveal|void)$/);
  if(stockAction&&req.method==='POST'){
   const item=db.prepare('SELECT * FROM inventory WHERE id=?').get(Number(stockAction[1]));if(!item)fail('库存不存在',404);if(stockAction[2]==='void'){if(item.status!=='available')fail('只能作废可用库存',409);db.prepare("UPDATE inventory SET status='void' WHERE id=?").run(item.id);audit(String(item.id),'inventory.void');json(res,200,{ok:true});}else{audit(String(item.id),'inventory.reveal');json(res,200,{code:item.code});}return true;
  }
  if(p==='/api/admin/tickets'&&req.method==='GET'){json(res,200,{tickets:db.prepare('SELECT t.*,o.contact,o.name_snapshot name FROM tickets t JOIN orders o ON o.id=t.order_id ORDER BY t.id DESC LIMIT 200').all()});return true;}
  const ticket=p.match(/^\/api\/admin\/tickets\/(\d+)$/);
  if(ticket&&req.method==='POST'){const reply=clean(b.reply,2000);if(reply.length<2||!['open','closed'].includes(b.status))fail('请填写回复及处理状态');if(!db.prepare('SELECT id FROM tickets WHERE id=?').get(Number(ticket[1])))fail('售后不存在',404);transaction(()=>{db.prepare('UPDATE tickets SET reply=?,status=?,updated=? WHERE id=?').run(reply,b.status,now(),Number(ticket[1]));audit(ticket[1],'ticket.replied');});json(res,200,{ok:true});return true;}
  if(p==='/api/admin/settings'){
   if(req.method==='GET'){json(res,200,{settings:{shopName:getSetting('shopName','商品与使用指南'),contact:getSetting('contact','sxzhaoniu'),announcement:getSetting('announcement','付款后由客服人工核实到账并发货。'),ordersEnabled:getSetting('ordersEnabled','true')==='true'}});return true;}
   if(req.method==='POST'){if(typeof b.ordersEnabled!=='boolean'||!clean(b.shopName,80)||!clean(b.contact,100))fail('店铺名称、联系方式不能为空');transaction(()=>{for(const [key,max] of [['shopName',80],['contact',100],['announcement',1000]])setSetting(key,clean(b[key],max));setSetting('ordersEnabled',b.ordersEnabled);audit('system','settings.updated');});json(res,200,{ok:true});return true;}
  }
  if(p==='/api/admin/password'&&req.method==='POST'){
   if(!verifyPassword(b.currentPassword))fail('当前密码不正确',403);if(typeof b.newPassword!=='string'||b.newPassword.length<14||b.newPassword.length>200)fail('新密码需要14至200位');transaction(()=>{const salt=randomBytes(16).toString('hex');setSetting('password',salt+':'+scryptSync(b.newPassword,salt,64).toString('hex'));db.exec('DELETE FROM sessions');audit('system','security.password_changed_all_sessions_revoked');});res.setHeader('Set-Cookie','admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0');json(res,200,{ok:true});return true;
  }
  if(req.method==='GET'&&p==='/api/admin/audit'){const page=Math.max(1,parseInt(url.searchParams.get('page')||'1')||1);json(res,200,{events:db.prepare('SELECT * FROM audit ORDER BY id DESC LIMIT 50 OFFSET ?').all((page-1)*50),page,total:db.prepare('SELECT COUNT(*) n FROM audit').get().n});return true;}
  if(req.method==='POST'&&p==='/api/admin/backups'){
   if(!verifyPassword(b.password))fail('请验证当前管理员密码',403);const filename='backup-'+now()+'-'+randomBytes(3).toString('hex')+'.sqlite';audit('system','backup.created');await backup(db,path.join(backupsDir,filename));json(res,200,{ok:true,filename});return true;
  }
  if(req.method==='GET'&&p==='/api/admin/backups'){json(res,200,{backups:readdirSync(backupsDir).filter(x=>/^backup-\d+-[a-f0-9]+\.sqlite$/.test(x)).map(name=>({name,size:statSync(path.join(backupsDir,name)).size})).sort((a,b)=>b.name.localeCompare(a.name))});return true;}
  const download=p.match(/^\/api\/admin\/backups\/(backup-\d+-[a-f0-9]+\.sqlite)$/);
  if(req.method==='GET'&&download){const file=path.join(backupsDir,download[1]);if(!existsSync(file))fail('备份不存在',404);audit('system','backup.downloaded');res.setHeader('Content-Type','application/octet-stream');res.setHeader('Content-Disposition',`attachment; filename="${download[1]}"`);res.end(readFileSync(file));return true;}
  return false;
 }
 return {route,getProduct,getSetting,listProducts,verifyPassword,audit};
}
