import test from 'node:test';
import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import path from 'node:path';
import {once} from 'node:events';
import {createStore} from './server.mjs';
test('manual payment, access control, fulfillment, persistence',async()=>{
 const dir=mkdtempSync(path.join(tmpdir(),'manual-store-')),origin='http://127.0.0.1:8787';let app=createStore({dataDir:dir,password:'test-only-password-123',origin});
 async function start(){app.server.listen(0,'127.0.0.1');await once(app.server,'listening');return 'http://127.0.0.1:'+app.server.address().port;}let base=await start();let cookie='',csrf='';
 const req=async(url,body,secret,admin=false,overrides={})=>{const r=await fetch(base+url,{method:body?'POST':'GET',headers:{Origin:origin,'Content-Type':'application/json',...(secret?{Authorization:'Bearer '+secret}:{}),...(admin?{Cookie:cookie,'X-CSRF-Token':csrf}:{}),...overrides},...(body?{body:JSON.stringify(body)}:{})});const data=await r.json();return {r,data};};
 try{
  const make=async()=>{const x=await req('/api/orders',{product:'plus',channel:'wechat',contact:'buyer@example.com',cents:1});assert.equal(x.r.status,201);assert.equal(x.data.cents,12000);return x.data;};
  const o=await make();assert.equal((await req('/api/orders/'+o.id)).r.status,404);assert.equal((await req('/api/admin/orders')).r.status,401);
  const review=await req('/api/orders/'+o.id+'/paid',{},o.secret);assert.equal(review.data.status,'review');assert.equal(review.data.code,undefined);
  assert.equal((await req('/api/orders',{product:'plus',channel:'wechat',contact:'tester'},null,false,{Origin:'https://attacker.invalid'})).r.status,403);
  assert.equal((await req('/api/admin/login',{password:'wrong'})).r.status,401);const login=await req('/api/admin/login',{password:'test-only-password-123'});cookie=login.r.headers.get('set-cookie').split(';')[0];csrf=login.data.csrf;assert.ok(login.r.headers.get('set-cookie').includes('HttpOnly'));
  const deliver={code:'CARD-ONE-PRIVATE',reference:'WECHAT-TXN-001',confirmed:true,amountCents:12000};
  assert.equal((await req('/api/admin/orders/'+o.id+'/fulfill',deliver,null,true,{'X-CSRF-Token':'invalid'})).r.status,403);
  assert.equal((await req('/api/admin/orders/'+o.id+'/fulfill',{...deliver,amountCents:1},null,true)).r.status,400);
  assert.equal((await req('/api/admin/orders/'+o.id+'/fulfill',deliver,null,true)).r.status,200);
  const result=await req('/api/orders/'+o.id,null,o.secret);assert.equal(result.data.code,deliver.code);assert.equal(result.data.status,'fulfilled');
  const again=await req('/api/admin/orders/'+o.id+'/fulfill',{...deliver,code:'OTHER-CODE'},null,true);assert.equal(again.data.alreadyFulfilled,true);assert.equal((await req('/api/orders/'+o.id,null,o.secret)).data.code,deliver.code);
  const o2=await make();assert.equal((await req('/api/admin/orders/'+o2.id+'/fulfill',{...deliver,code:'SECOND-CODE'},null,true)).r.status,409);assert.equal((await req('/api/admin/orders/'+o2.id+'/fulfill',{...deliver,reference:'ANOTHER-TXN'},null,true)).r.status,409);
  assert.equal((await req('/api/orders/'+o.id,null,o2.secret)).r.status,404);
  await req('/api/admin/orders/'+o2.id+'/cancel',{},null,true);assert.equal((await req('/api/admin/orders/'+o2.id+'/fulfill',{...deliver,reference:'NEW-TXN',code:'NEW-CODE'},null,true)).r.status,409);
  await new Promise(r=>app.server.close(r));app.close();app=createStore({dataDir:dir,password:'test-only-password-123',origin});base=await start();assert.equal((await req('/api/orders/'+o.id,null,o.secret)).data.code,deliver.code);
  assert.equal((await req('/api/admin/logout',{},null,true)).r.status,200);assert.equal((await req('/api/admin/orders',null,null,true)).r.status,401);
 }finally{await new Promise(r=>app.server.close(r));app.close();rmSync(dir,{recursive:true,force:true});}
});
