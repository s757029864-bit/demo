$ErrorActionPreference = 'Stop'
Set-Location -LiteralPath $PSScriptRoot
Write-Host '商品页面：http://127.0.0.1:8787/'
Write-Host '管理后台：http://127.0.0.1:8787/admin'
node local-start.mjs
