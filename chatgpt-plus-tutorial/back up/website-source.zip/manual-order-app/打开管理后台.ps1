$ErrorActionPreference = 'Stop'
$adminUrl = 'http://127.0.0.1:8787/admin'
$isReady = $false
try {
    $response = Invoke-WebRequest -Uri $adminUrl -UseBasicParsing -TimeoutSec 3
    $isReady = $response.StatusCode -eq 200 -and $response.Content.Contains('经营管理后台')
} catch {}
if (-not $isReady) {
    $runtimeNode = (Get-Command node -ErrorAction Stop).Source
    Start-Process -FilePath $runtimeNode -ArgumentList 'local-start.mjs' -WorkingDirectory $PSScriptRoot -WindowStyle Hidden -RedirectStandardOutput (Join-Path $PSScriptRoot 'local-server.log') -RedirectStandardError (Join-Path $PSScriptRoot 'local-server-error.log')
    for ($attempt = 0; $attempt -lt 20; $attempt++) {
        Start-Sleep -Milliseconds 400
        try {
            $response = Invoke-WebRequest -Uri $adminUrl -UseBasicParsing -TimeoutSec 2
            if ($response.StatusCode -eq 200 -and $response.Content.Contains('经营管理后台')) { $isReady = $true; break }
        } catch {}
    }
}
if (-not $isReady) { throw '后台未能启动，请检查 local-server-error.log，或确认8787端口没有被其他程序占用。' }
Start-Process $adminUrl
