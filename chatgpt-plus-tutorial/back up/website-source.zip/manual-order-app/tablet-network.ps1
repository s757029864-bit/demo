$ErrorActionPreference = 'Stop'
$identity = [Security.Principal.WindowsIdentity]::GetCurrent()
$principal = New-Object Security.Principal.WindowsPrincipal($identity)
if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    Start-Process -FilePath 'powershell.exe' -Verb RunAs -ArgumentList ('-NoProfile -ExecutionPolicy Bypass -File "' + $PSCommandPath + '"')
    exit
}
try {
    $network = Get-NetIPConfiguration | Where-Object { $_.IPv4DefaultGateway -and $_.InterfaceAlias -eq 'WLAN' } | Select-Object -First 1
    if (-not $network) { throw '未找到连接中的WLAN网络，请先连接Wi-Fi。' }
    $address = ($network.IPv4Address | Select-Object -First 1).IPAddress
    $ruleName = 'ManualStore-Tablet-8787'
    $rule = Get-NetFirewallRule -Name $ruleName -ErrorAction SilentlyContinue
    if ($rule) {
        Set-NetFirewallRule -Name $ruleName -Enabled True -Direction Inbound -Action Allow -Profile Any -InterfaceAlias $network.InterfaceAlias -Protocol TCP -LocalPort 8787 -LocalAddress $address -RemoteAddress LocalSubnet | Out-Null
    } else {
        New-NetFirewallRule -Name $ruleName -DisplayName 'Manual Store Tablet Access (WLAN only)' -Direction Inbound -Action Allow -Protocol TCP -LocalPort 8787 -LocalAddress $address -RemoteAddress LocalSubnet -InterfaceAlias $network.InterfaceAlias -Profile Any | Out-Null
    }
    Write-Host ('设置成功。平板与电脑连接同一Wi-Fi后打开：http://' + $address + ':8787/admin')
} catch { Write-Host $_.Exception.Message }
Read-Host '按回车关闭'
