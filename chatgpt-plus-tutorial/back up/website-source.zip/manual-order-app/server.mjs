import http from 'node:http';
import {DatabaseSync} from 'node:sqlite';
import {randomBytes,createHash} from 'node:crypto';
import {mkdirSync,readFileSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {createManagement} from './management.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
export const products=[{id:'plus',name:'gtp 普拉斯',cents:12000},{id:'5x',name:'gtp 5x',cents:67000},{id:'20x',name:'gtp 20x',cents:110000},{id:'50x',name:'gtp 50x',cents:330000},{id:'google-new',name:'个人新号',cents:1500},{id:'google-old',name:'个人老号',cents:2500},{id:'sms-us',name:'美区接码',cents:500}];
const hash=s=>createHash('sha256').update(s).digest('hex');
const token=()=>randomBytes(32).toString('hex');
export function createStore({dataDir=process.env.DATA_DIR||path.join(here,'data'),password=process.env.ADMIN_PASSWORD,origin=process.env.PUBLIC_ORIGIN||'http://127.0.0.1:8787',secure=origin.startsWith('https:'),allowedOrigins=[origin]}={}){
 if(!password||password.length<14)throw Error('请设置至少14位的 ADMIN_PASSWORD');
 origin=new URL(origin).origin;const origins=new Set(allowedOrigins.map(value=>new URL(value).origin));mkdirSync(dataDir,{recursive:true});
 const db=new DatabaseSync(path.join(dataDir,'orders.sqlite'));db.exec(`PRAGMA journal_mode=WAL;PRAGMA busy_timeout=5000;CREATE TABLE IF NOT EXISTS orders(id TEXT PRIMARY KEY,secret_hash TEXT NOT NULL,product TEXT NOT NULL,cents INTEGER NOT NULL,contact TEXT NOT NULL,status TEXT NOT NULL,code TEXT,created INTEGER NOT NULL,updated INTEGER NOT NULL,reference TEXT);CREATE TABLE IF NOT EXISTS sessions(hash TEXT PRIMARY KEY,csrf TEXT NOT NULL,expires INTEGER NOT NULL);CREATE TABLE IF NOT EXISTS audit(id INTEGER PRIMARY KEY,order_id TEXT NOT NULL,action TEXT NOT NULL,created INTEGER NOT NULL);CREATE UNIQUE INDEX IF NOT EXISTS unique_delivered_code ON orders(code) WHERE code IS NOT NULL;CREATE UNIQUE INDEX IF NOT EXISTS unique_payment_reference ON orders(reference) WHERE reference IS NOT NULL;`);
 const rates=new Map();
 function limit(key,max){const now=Date.now();if(rates.size>10000)for(const [k,v] of rates)if(now-v.time>900000)rates.delete(k);let v=rates.get(key);if(!v||now-v.time>900000){v={time:now,n:0};rates.set(key,v);}if(++v.n>max)fail('操作频繁，请稍后重试',429);}
 function fail(message,status=400){throw Object.assign(Error(message),{status});}
 const json=(res,status,data)=>{res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(data));};
 function session(req){const raw=req.headers.cookie?.split(';').map(x=>x.trim()).find(x=>x.startsWith('admin='))?.slice(6)||'';return db.prepare('SELECT * FROM sessions WHERE hash=? AND expires>?').get(hash(raw),Date.now());}
 function admin(req,mutating=false){const s=session(req);if(!s)fail('请先登录管理后台',401);if(mutating&&req.headers['x-csrf-token']!==s.csrf)fail('会话已变化，请刷新后重试',403);return s;}
 function own(req,id){const secret=(req.headers.authorization||'').replace(/^Bearer /,'');const o=db.prepare('SELECT * FROM orders WHERE id=? AND secret_hash=?').get(id,hash(secret));if(!o)fail('订单号或查询凭证不正确',404);return o;}
 const view=o=>({id:o.id,product:o.product,name:o.name_snapshot||products.find(p=>p.id===o.product)?.name,cents:o.cents,status:o.status,created:o.created,updated:o.updated,refundCents:o.refund_cents||0,...(o.status==='fulfilled'?{code:o.code}:{})});
 const management=createManagement({db,products,dataDir,fail,json,admin,session,password,view});
 async function body(req){let s='';for await(const c of req){s+=c;if(Buffer.byteLength(s)>1000000)fail('提交内容过长',413);}try{const b=JSON.parse(s||'{}');if(!b||typeof b!=='object'||Array.isArray(b))fail('请求格式无效');return b;}catch{fail('请求格式无效');}}
 const server=http.createServer(async(req,res)=>{
  res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'");
  try{
   const url=new URL(req.url,origin),p=url.pathname,ip=req.socket.remoteAddress||'';
   if(p.startsWith('/api/'))limit('api:'+ip,400);
   if(req.method==='POST'&&!origins.has(req.headers.origin))fail('请求来源无效',403);
   const b=req.method==='POST'?await body(req):{};
   if(await management.route(req,res,p,b,url))return;
   if(req.method==='POST'&&p==='/api/orders/lookup'){
    limit('lookup:'+ip,10);const contact=String(b.contact||'').trim();if(contact.length<3||contact.length>100)fail('请完整填写联系信息');
    const orders=db.prepare('SELECT id,product,name_snapshot,cents,status,created FROM orders WHERE contact=? ORDER BY created DESC LIMIT 50').all(contact).map(o=>({id:o.id,name:o.name_snapshot||products.find(p=>p.id===o.product)?.name,cents:o.cents,status:o.status,created:o.created}));return json(res,200,{orders});
   }
   if(req.method==='POST'&&p==='/api/orders'){
    limit('create:'+ip,20);if(management.getSetting('ordersEnabled','true')!=='true')fail('店铺暂时停止接单，请稍后再来',503);const product=management.getProduct(b.product);if(!product||b.channel!=='wechat')fail('商品未上架或付款方式无效');if(b.expectedCents!==undefined&&b.expectedCents!==product.cents)fail('商品价格已调整，请刷新后确认',409);if(product.sale_stock!==null&&product.sale_stock<=0)fail('商品暂时售罄',409);const contact=String(b.contact||'').trim();if(contact.length<3||contact.length>100)fail('请填写3至100字的微信号、手机号或邮箱');const id='M'+Date.now().toString(36).toUpperCase()+randomBytes(5).toString('hex').toUpperCase(),secret=token(),now=Date.now();
    db.prepare('INSERT INTO orders(id,secret_hash,product,cents,contact,status,created,updated,name_snapshot) VALUES(?,?,?,?,?,?,?,?,?)').run(id,hash(secret),product.id,product.cents,contact,'pending',now,now,product.name);management.audit(id,'order.created');return json(res,201,{...view(db.prepare('SELECT * FROM orders WHERE id=?').get(id)),secret});
   }
   const match=p.match(/^\/api\/orders\/([A-Z0-9]+)(\/paid)?$/);
   if(match){const o=own(req,match[1]);if(req.method==='POST'&&match[2]){if(o.status==='pending'){db.prepare("UPDATE orders SET status='review',updated=? WHERE id=? AND status='pending'").run(Date.now(),o.id);}return json(res,200,view(own(req,o.id)));}if(req.method==='GET'&&!match[2])return json(res,200,view(o));}
   const support=p.match(/^\/api\/orders\/([A-Z0-9]+)\/support$/);
   if(support){const o=own(req,support[1]);if(req.method==='GET')return json(res,200,{tickets:db.prepare('SELECT id,reason,status,reply,created,updated FROM tickets WHERE order_id=? ORDER BY id DESC').all(o.id)});if(req.method==='POST'){limit('support:'+ip,30);const reason=String(b.reason||'').trim();if(reason.length<5||reason.length>2000)fail('售后说明需要5至2000字');if(db.prepare("SELECT id FROM tickets WHERE order_id=? AND status='open'").get(o.id))fail('已有待处理售后，请等待客服回复',409);const t=Date.now();db.prepare('INSERT INTO tickets(order_id,reason,created,updated) VALUES(?,?,?,?)').run(o.id,reason,t,t);management.audit(o.id,'support.requested');return json(res,201,{ok:true});}}
   if(req.method==='POST'&&p==='/api/admin/login'){
    limit('login:'+ip,10);const entered=String(b.password||'');if(!management.verifyPassword(entered))fail('密码不正确',401);const raw=token(),csrf=token();db.prepare('DELETE FROM sessions WHERE expires<=?').run(Date.now());db.prepare('INSERT INTO sessions VALUES(?,?,?)').run(hash(raw),csrf,Date.now()+8*3600000);management.audit('system','admin.login');res.setHeader('Set-Cookie',`admin=${raw}; HttpOnly; SameSite=Strict; Path=/; Max-Age=28800${secure?'; Secure':''}`);return json(res,200,{csrf});
   }
   if(req.method==='POST'&&p==='/api/admin/logout'){const s=admin(req,true);db.prepare('DELETE FROM sessions WHERE hash=?').run(s.hash);res.setHeader('Set-Cookie',`admin=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0${secure?'; Secure':''}`);return json(res,200,{ok:true});}
   if(req.method==='GET'){
    const files={'/':'index.html','/checkout':'checkout.html','/chatgpt-guide':'chatgpt-guide.html','/guide.js':'guide.js','/google-guide':'google-guide.html','/google-guide.js':'google-guide.js','/assets/google-step-1.png':'assets/google-step-1.png','/assets/google-step-2.png':'assets/google-step-2.png','/assets/google-step-3.png':'assets/google-step-3.png','/assets/google-step-4.png':'assets/google-step-4.png','/assets/google-step-5.png':'assets/google-step-5.png','/assets/google-step-6.png':'assets/google-step-6.png','/admin':'admin.html','/app.js':'app.js','/purchase-notice.js':'purchase-notice.js','/admin.js':'admin.js','/admin.css':'admin.css','/style.css':'style.css','/refined-theme.css':'refined-theme.css','/assets/wechat-pay.jpg':'assets/wechat-pay.jpg','/assets/codex-logo.png':'assets/codex-logo.png'};const file=files[p];if(file){res.setHeader('Content-Type',file.endsWith('.png')?'image/png':file.endsWith('.jpg')?'image/jpeg':file.endsWith('.js')?'text/javascript; charset=utf-8':file.endsWith('.css')?'text/css; charset=utf-8':'text/html; charset=utf-8');return res.end(readFileSync(path.join(here,'public',file)));}
   }fail('页面不存在',404);
  }catch(e){json(res,e.status||500,{error:e.status?e.message:'服务暂时不可用，请稍后重试'});}
 });return {server,db,close(){db.close();}};
}
if(process.argv[1]===fileURLToPath(import.meta.url)){const app=createStore();app.server.listen(Number(process.env.PORT||8787),'127.0.0.1',()=>console.log('人工确认商城：http://127.0.0.1:'+(process.env.PORT||8787)));}
