import {readFileSync,writeFileSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createStore} from './server.mjs';
import {networkInterfaces} from 'node:os';
const here=path.dirname(fileURLToPath(import.meta.url));
const passwordFile=path.join(here,'.local-admin-password.txt');
let password;
try{password=readFileSync(passwordFile,'utf8').trim();}catch{password=randomBytes(15).toString('base64url');writeFileSync(passwordFile,password+'\n',{mode:0o600,flag:'wx'});}
const lan=process.argv.includes('--lan');
const addresses=Object.values(networkInterfaces()).flat().filter(x=>x.family==='IPv4'&&!x.internal&&/^(192\.168\.|10\.|172\.(1[6-9]|2\d|3[01])\.)/.test(x.address)).map(x=>x.address);
const allowedOrigins=['http://127.0.0.1:8787','http://localhost:8787',...(lan?addresses.map(ip=>'http://'+ip+':8787'):[])];
const app=createStore({password,origin:'http://127.0.0.1:8787',secure:false,allowedOrigins});
app.server.listen(8787,lan?'0.0.0.0':'127.0.0.1',()=>{
 console.log('商品页面：http://127.0.0.1:8787/\n管理后台：http://127.0.0.1:8787/admin');
 if(lan)for(const ip of addresses)console.log('同网络平板访问：http://'+ip+':8787/admin');
 console.log('首次密码保存在 .local-admin-password.txt；若已在后台修改密码，请使用修改后的密码。');
});
