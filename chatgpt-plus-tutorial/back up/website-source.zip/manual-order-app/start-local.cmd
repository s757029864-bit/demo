@echo off
cd /d "%~dp0"
node local-start.mjs
pause
