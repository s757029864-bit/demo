import {DatabaseSync} from 'node:sqlite';
import {existsSync,mkdirSync,copyFileSync,constants,unlinkSync} from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export function restoreBackup(source,targetDir){
 const sourcePath=path.resolve(source),dir=path.resolve(targetDir),target=path.join(dir,'orders.sqlite');
 if(!existsSync(sourcePath))throw Error('备份文件不存在');
 if(existsSync(target)||existsSync(target+'-wal')||existsSync(target+'-shm'))throw Error('目标已有数据库，请使用新的空目录，避免覆盖订单');
 const original=new DatabaseSync(sourcePath,{readOnly:true});
 try{if(original.prepare('PRAGMA integrity_check').get().integrity_check!=='ok')throw Error('备份文件校验失败');for(const name of ['orders','catalog','inventory','tickets','settings','audit','sessions'])if(!original.prepare("SELECT name FROM sqlite_master WHERE type='table' AND name=?").get(name))throw Error('备份缺少必要数据表');}finally{original.close();}
 mkdirSync(dir,{recursive:true});copyFileSync(sourcePath,target,constants.COPYFILE_EXCL);const restored=new DatabaseSync(target);try{restored.exec('DELETE FROM sessions; PRAGMA journal_mode=DELETE;');}finally{restored.close();}return target;
}
if(process.argv[1]===fileURLToPath(import.meta.url)){try{if(!process.argv[2]||!process.argv[3])throw Error('用法：node restore.mjs <备份.sqlite> <新的数据目录>');console.log('已恢复到：'+restoreBackup(process.argv[2],process.argv[3]));console.log('启动前将 DATA_DIR 设为该目录，管理员密码为备份创建时的密码。');}catch(e){console.error(e.message);process.exitCode=1;}}
