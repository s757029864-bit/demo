import {spawn} from 'node:child_process';
import {readFileSync,writeFileSync,existsSync,appendFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
import {createStore} from './server.mjs';
const here=path.dirname(fileURLToPath(import.meta.url));
const binary=process.env.CLOUDFLARED_PATH||path.resolve(here,'../.tools/cloudflared.exe');
if(!existsSync(binary))throw Error('未找到cloudflared，请先完成官方工具下载。');
const password=readFileSync(path.join(here,'.local-admin-password.txt'),'utf8').trim();
const log=path.join(here,'free-tunnel.log');
const tunnel=spawn(binary,['--no-autoupdate','tunnel','--url','http://127.0.0.1:8788','--protocol','http2'],{windowsHide:true,stdio:['ignore','pipe','pipe']});
let app,started=false,tail='';
function output(chunk){const s=chunk.toString();appendFileSync(log,s);tail=(tail+s).slice(-20000);const match=tail.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/);if(match&&!started){started=true;const origin=match[0];try{app=createStore({password,origin,secure:true});app.server.on('error',e=>{console.error(e.message);tunnel.kill();});app.server.listen(8788,'127.0.0.1',()=>{writeFileSync(path.join(here,'.public-link.txt'),origin+'\n');console.log('免费临时商品页：'+origin+'\n免费临时管理后台：'+origin+'/admin\n电脑及本进程必须保持运行，重开后链接变化。');});}catch(e){console.error(e.message);tunnel.kill();}}if(s.includes('Registered tunnel connection'))console.log('公网隧道连接已建立');if(s.includes('ERR'))console.error(s.trim());}
tunnel.stdout.on('data',output);tunnel.stderr.on('data',output);tunnel.on('error',e=>{console.error(e.message);process.exitCode=1;});tunnel.on('exit',code=>{console.log('临时公网隧道已关闭');if(app)app.server.close(()=>app.close());process.exitCode=code||0;});
for(const signal of ['SIGINT','SIGTERM'])process.on(signal,()=>tunnel.kill());
