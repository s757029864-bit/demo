@echo off
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0打开管理后台.ps1"
if errorlevel 1 pause
