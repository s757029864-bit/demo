@echo off
cd /d "%~dp0"
node free-public.mjs
pause
