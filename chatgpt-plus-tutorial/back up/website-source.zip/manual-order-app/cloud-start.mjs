import {createStore} from './server.mjs';
const origin=process.env.PUBLIC_ORIGIN||process.env.RENDER_EXTERNAL_URL;
if(!origin||!origin.startsWith('https://'))throw Error('公网部署需要设置有效的 HTTPS PUBLIC_ORIGIN 或 RENDER_EXTERNAL_URL');
if(!process.env.DATA_DIR)throw Error('请设置持久化存储路径 DATA_DIR');
const app=createStore({origin,password:process.env.ADMIN_PASSWORD,dataDir:process.env.DATA_DIR,secure:true});
app.server.listen(Number(process.env.PORT||10000),'0.0.0.0',()=>console.log('公网商城服务已启动'));
let closing=false;
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>{if(closing)return;closing=true;app.server.close(()=>{app.close();process.exit(0);});setTimeout(()=>process.exit(1),25000).unref();});
